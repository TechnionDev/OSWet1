#ifndef SMASH_COMMAND_H_
#define SMASH_COMMAND_H_

#include <vector>
#include <map>
#include <chrono>
#include <string>
#include <sstream>
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
using namespace std;

#define COMMAND_ARGS_MAX_LENGTH (200)
#define COMMAND_MAX_ARGS (20)
#define HISTORY_MAX_RECORDS (50)
vector<string> parseCommandLine(const char *cmd_line);
class Command
{
  // TODO: Add your data members
protected:  
  std::vector<std::string> args;
public:
  string cmd_line;
  Command(const char *cmd_line) : cmd_line(cmd_line){
    args=parseCommandLine(cmd_line);
  };
  virtual ~Command(){};
  virtual void execute() = 0;
  //virtual void prepare();
  //virtual void cleanup();
  // TODO: Add your extra methods if needed
  string getCommandName();
};

class BuiltInCommand : public Command
{
public:
  BuiltInCommand(const char *cmd_line) : Command{cmd_line} {};
  virtual ~BuiltInCommand() {}
};

class ExternalCommand : public Command
{
public:
  ExternalCommand(const char *cmd_line);
  virtual ~ExternalCommand() {}
  void execute() override;
};

class PipeCommand : public Command
{
  // TODO: Add your data members
public:
  PipeCommand(const char *cmd_line);
  virtual ~PipeCommand() {}
  void execute() override;
};

class RedirectionCommand : public Command
{
protected:
  std::ofstream fileOutput;

public:
  explicit RedirectionCommand(const char *cmd_line);
  virtual ~RedirectionCommand() {}
  void execute() override;
  virtual void prepare() {}
  void cleanup();
};
class OverrideRedirectionCommand : public RedirectionCommand
{
  // TODO: Add your data members
public:
  explicit OverrideRedirectionCommand(const char *cmd_line);
  virtual ~OverrideRedirectionCommand() {}
  void prepare() override;
};
class AppendRedirectionCommand : public RedirectionCommand
{
public:
  explicit AppendRedirectionCommand(const char *cmd_line);
  virtual ~AppendRedirectionCommand() {}
  void prepare() override;
};

class ChangeDirCommand : public BuiltInCommand
{
public:
  ChangeDirCommand(const char *cmd_line);
  virtual ~ChangeDirCommand() {}
  void execute() override;
};

class GetCurrDirCommand : public BuiltInCommand
{
public:
  GetCurrDirCommand(const char *cmd_line);
  virtual ~GetCurrDirCommand() {}
  void execute() override;
};

class ShowPidCommand : public BuiltInCommand
{
public:
  ShowPidCommand(const char *cmd_line);
  virtual ~ShowPidCommand() {}
  void execute() override;
};
class CopyCommand : public BuiltInCommand
{
  public:
    CopyCommand(const char *cmd_line);
    virtual ~CopyCommand() {}
    void execute() override;
};
class JobsList;
class QuitCommand : public BuiltInCommand
{
  // TODO: Add your data members public:
public:
  JobsList *jobs;
  QuitCommand(const char *cmd_line);
  virtual ~QuitCommand() {}
  void execute() override;
};

class JobsList {  
 public:
  class JobEntry {    
    public:      
      JobEntry(int pid,int jid,string cmd_line,int insertTime):
        id(jid),pid(pid),cmd_line(cmd_line),insertTime(insertTime)
      {   
      }
      JobEntry(){}
      int id;
      int pid;
      
      //Command* cmd;
      int insertTime;      
      bool isStopped;
      string cmd_line;      
      string getCommandName();
      // bool getIsStopped();
      // friend bool operator<(const JobEntry& l, const JobEntry& r){
      //   return l.id<r.id;
      // }
  };  
  JobsList();
  ~JobsList();
  void addJob(int pid,Command* cmd, bool isStopped = false);
  void printJobsList();
  void killAllJobs();
  void removeFinishedJobs();
  JobEntry *getJobById(int jobId);
  void removeJobById(int jobId);
  JobEntry *getLastJob(int *lastJobId);
  JobEntry *getLastStoppedJob(int *jobId);
  size_t getJobCount();

  // TODO: Add your data members
  std::map<int, JobEntry *> jobsMap;

  // TODO: Add extra methods or modify exisitng ones as needed
  double getElapsedSeconds(JobEntry& job);
  int killJob(int jobId,int sig);
};

class JobsCommand : public BuiltInCommand
{
  // TODO: Add your data members
  JobsList *jobslist;

public:
  JobsCommand(const char *cmd_line, JobsList *jobs);
  virtual ~JobsCommand() {}
  void execute() override;
};

class KillCommand : public BuiltInCommand {
 // TODO: Add your data members
 JobsList* jobslist;
 public:
  KillCommand(const char* cmd_line, JobsList* jobs);
  virtual ~KillCommand() {}
  void execute() override;
};

class ForegroundCommand : public BuiltInCommand
{
  JobsList* jobslist;
  // TODO: Add your data members
  public:
  ForegroundCommand(const char *cmd_line, JobsList *jobs);
  virtual ~ForegroundCommand() {}
  void execute() override;
};

class BackgroundCommand : public BuiltInCommand
{
  JobsList* jobslist;
  // TODO: Add your data members
public:
  BackgroundCommand(const char *cmd_line, JobsList *jobs);
  virtual ~BackgroundCommand() {}
  void execute() override;
};

class ListDirectoryCommand : public BuiltInCommand
{
public:
  ListDirectoryCommand(const char *cmd_line);
  virtual ~ListDirectoryCommand() {}
  void execute() override;
};
class ChangePromptCommand : public BuiltInCommand
{
public:
  ChangePromptCommand(const char *cmd_line);
  virtual ~ChangePromptCommand() {}
  void execute() override;
};

class TimeOutCommand : public Command
{
  private:
    std::string inner_command;
    pid_t inner_pid;
  public: 
    TimeOutCommand(const char *cmd_line);
    virtual ~TimeOutCommand() {}
    void execute() override;
    void processAlarm(int signum);

}; 
class SmallShell
{
private:
  bool last_command_set;
  std::string prompt;
  SmallShell();

public:
  Command* currentCommand;
  int currentFgJobId;
  bool terminate;
  JobsList jobslist;
  bool is_timed_out;
  pid_t child_timed_out;
  string timedout_command;
  char *last_cd;
  Command *CreateCommand(const char *cmd_line);
  SmallShell(SmallShell const &) = delete;     // disable copy ctor
  void operator=(SmallShell const &) = delete; // disable = operator
  static SmallShell &getInstance()             // make SmallShell singleton
  {
    static SmallShell instance; // Guaranteed to be destroyed.
    // Instantiated on first use.
    return instance;
  }
  ~SmallShell();
  void executeCommand(const char *cmd_line);
  void changePrompt(const std::string prompt);
  std::string getPrompt();
  bool is_last_command_set();
  void turn_last_command_flag_on();
};

#endif //SMASH_COMMAND_H_
