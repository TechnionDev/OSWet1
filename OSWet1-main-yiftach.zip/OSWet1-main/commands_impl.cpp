#include <dirent.h>
#include <map>
#include <chrono>
#include <time.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

using namespace std;

bool is_pid_running(pid_t pid)
{

  while (waitpid(-1, 0, WNOHANG) > 0)
  {
  }

  if (0 == kill(pid, 0))
    return true;

  return false;
}

vector<string> parseCommandLine(const char *cmd_line)
{

  char **argv = new char *[20];
  for (size_t i = 0; i < 20; i++)
  {
    argv[i] = new char[30];
  }
  int param_count = _parseCommandLine(cmd_line, argv);
  vector<string> commands = vector<string>(param_count);
  for (size_t i = 0; i < param_count; i++)
  {
    commands[i] = string(argv[i]);
  }
  for (size_t i = 0; i < 20; i++)
  {
    delete[] argv[i];
  }

  delete[] argv;
  return commands;
}

string Command::getCommandName()
{
  return parseCommandLine(this->cmd_line.c_str())[0];
}

GetCurrDirCommand::GetCurrDirCommand(const char *cmd_line) : BuiltInCommand{cmd_line} {}
void GetCurrDirCommand::execute()
{
  char *out = new char[100];
  std::cout << getcwd(out, 100) << std::endl;
  delete[] out;
}

ShowPidCommand::ShowPidCommand(const char *cmd_line) : BuiltInCommand{cmd_line} {}
void ShowPidCommand::execute()
{
  std::cout << "smash pid is " << getpid() << std::endl;
}

ListDirectoryCommand::ListDirectoryCommand(const char *cmd_line) : BuiltInCommand{cmd_line} {}
void ListDirectoryCommand::execute()
{
  dirent **namelist;
  int n = scandir(".", &namelist, 0, alphasort);
  if (n < 0)
    perror("scandir");
  else
  {
    for (size_t i = 0; i < n; i++)
    {
      std::cout << namelist[i]->d_name << std::endl;
      free(namelist[i]);
    }
    free(namelist);
  }
}
ChangePromptCommand::ChangePromptCommand(const char *cmd_line) : BuiltInCommand{cmd_line} {}
void ChangePromptCommand::execute()
{
  SmallShell &smash = SmallShell::getInstance();
  vector<string> params = parseCommandLine(cmd_line.c_str());
  if (0 != params.size())
  {
    smash.changePrompt(params[1]);
  }
  else
  {
    smash.changePrompt("smash");
  }
}
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ cp command ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
CopyCommand::CopyCommand(const char *cmd_line) : BuiltInCommand{cmd_line} {}
void CopyCommand::execute()
{
  uint8_t page[PAGE_BUFFER_4K];
  auto input_fd = open(args[1].c_str(), O_RDONLY);
  auto output_fd = open(args[2].c_str(), O_CREAT | O_TRUNC, 0777);
  std::cout<<"input fd "<<input_fd<<std::endl;
  std::cout<<"output fd "<<output_fd<<std::endl;
  ssize_t read_size;
  do
  {
    read_size= read(input_fd, page, PAGE_BUFFER_4K);
     std::cout<<"read size is  "<<read_size<<std::endl;
    
    auto write_output = write(output_fd,page,read_size);
        std::cout<<"write output is "<<write_output<<std::endl;

  }
  while(read_size>0);
  close(input_fd);
  close(output_fd);
}

QuitCommand::QuitCommand(const char *cmd_line) : BuiltInCommand{cmd_line}
{
}

void QuitCommand::execute()
{
  // std::cout<<"sending SIGKILL signal to "<<jobs->getJobCount()<<" jobs"<<std::endl;
  // jobs->printJobsList();
  // jobs->killAllJobs();
  exit(1);
}

KillCommand::KillCommand(const char *cmd_line, JobsList *jobs) : jobslist(jobs), BuiltInCommand(cmd_line)
{
}

void KillCommand::execute()
{
  // ctodo: validate args

  auto parsedCmd = parseCommandLine(cmd_line.c_str());
  int sigToSend = stoi(parsedCmd[1].substr(1));
  int jidToKill = stoi(parsedCmd[2]);
  this->jobslist->killJob(jidToKill, sigToSend);
}

JobsCommand::JobsCommand(const char *cmd_line, JobsList *jobs) : jobslist(jobs), BuiltInCommand{cmd_line}
{
}

void JobsCommand::execute()
{
  this->jobslist->printJobsList();
}

BackgroundCommand::BackgroundCommand(const char *cmd_line, JobsList *jobs) : jobslist(jobs), BuiltInCommand{cmd_line}
{
}

void BackgroundCommand::execute()
{
  int jidToBg = stoi(parseCommandLine(cmd_line.c_str())[1]);  
  JobsList::JobEntry *job = this->jobslist->getJobById(jidToBg);
  cout << job->cmd_line<<endl;  
  kill(job->pid,SIGCONT);
}

ForegroundCommand::ForegroundCommand(const char *cmd_line, JobsList *jobs) : jobslist(jobs), BuiltInCommand{cmd_line}
{
}

void ForegroundCommand::execute()
{
  int jidToFg = stoi(parseCommandLine(cmd_line.c_str())[1]);
  int jobPid = this->jobslist->getJobById(jidToFg)->pid;
  SmallShell::getInstance().currentFgJobId = jidToFg;
  //cout<<"waitpid to "<<
  waitpid(jobPid, NULL, 0);

  SmallShell::getInstance().currentFgJobId = -1;
}

ChangeDirCommand::ChangeDirCommand(const char *cmd_line) : BuiltInCommand{cmd_line} {}

void ChangeDirCommand::execute()
{
  SmallShell &smash = SmallShell::getInstance();

  char *out = new char[100];
  out = getcwd(out, 100);

  vector<string> params = parseCommandLine(cmd_line.c_str());
  if (params.size() > 2)
  {
    perror("smash error: cd: too many arguments");
    return;
  }
  if (params[1] == "-")
  {
    if (smash.is_last_command_set())
    {
      chdir(smash.last_cd);
    }
    else
    {
      perror("error: cd: OLDPWD not set");
    }
  }
  else
  {
    chdir(params[1].c_str());
  }
  strcpy(smash.last_cd, out);
  smash.turn_last_command_flag_on();
  delete[] out;
}

ExternalCommand::ExternalCommand(const char *cmd_line) : Command(cmd_line)
{
}
void ExternalCommand::execute()
{

  char *argv[4];
  char out[200] = "";
  argv[0] = "/bin/bash";
  argv[1] = "-c";
  //strcat(out, (char*)"\"");
  strcat(out, cmd_line.c_str());
  //strcat(out, (char*)"\"");
  argv[2] = out;
  argv[3] = NULL;
  int pid = fork();
  if (pid == 0)
  {
    setpgrp();
    execv(argv[0], argv);
  }
  else
  {
    wait(NULL);
  }
}

PipeCommand::PipeCommand(const char *cmd_line) : Command(cmd_line)
{
}
void PipeCommand::execute()
{
  int current = cmd_line.find("|&");
  Command *command_a, *command_b;
  FILE *output;
  bool is_redirect = false;
  if (current != std::string::npos)
  {
    output = stderr;
    command_a = SmallShell::getInstance().CreateCommand(cmd_line.substr(0, current - 1).c_str());
    command_b = SmallShell::getInstance().CreateCommand(cmd_line.substr(current + 2, cmd_line.size() - current + 1).c_str());
  }
  else
  {
    current = cmd_line.find("|");
    output = stdout;
    if (current != std::string::npos)
    {
      current = cmd_line.find("|");
      command_a = SmallShell::getInstance().CreateCommand(cmd_line.substr(0, current - 1).c_str());
      command_b = SmallShell::getInstance().CreateCommand(cmd_line.substr(current + 1, cmd_line.size() - current).c_str());
    }
    else
    {
      is_redirect = true;
      current = cmd_line.find(">>");
      if (current != std::string::npos)
      {
        command_a = SmallShell::getInstance().CreateCommand(cmd_line.substr(0, current - 1).c_str());
        command_b = (Command *)new AppendRedirectionCommand(cmd_line.substr(current + 2, cmd_line.size() - current).c_str());
      }
      else
      {
        current = cmd_line.find(">");
        command_a = SmallShell::getInstance().CreateCommand(cmd_line.substr(0, current - 1).c_str());
        command_b = (Command *)new OverrideRedirectionCommand(cmd_line.substr(current + 1, cmd_line.size() - current).c_str());
      }
    }
  }
  int pipe_cmd[2];
  pipe(pipe_cmd);
  pid_t fromPid = fork();
  if (fromPid == 0)
  {
    setpgrp();
    dup2(pipe_cmd[1], fileno(output)); // redirect the output (STDOUT to the pipe)
    close(pipe_cmd[0]);
    close(pipe_cmd[1]);
    command_a->execute();
    exit(0);
  }
  if (is_redirect)
  {
    waitpid(fromPid, NULL, 0);
  }
  pid_t toPid = fork();
  if (toPid == 0)
  {
    setpgrp();
    dup2(pipe_cmd[0], fileno(stdin)); // redirect the input (STDIN to the pipe)
    close(pipe_cmd[0]);
    close(pipe_cmd[1]);
    command_b->execute();
    exit(0);
  }
  close(pipe_cmd[0]);
  close(pipe_cmd[1]);
  if (!is_redirect)
  {
    waitpid(fromPid, NULL, 0);
  }
  waitpid(toPid, NULL, 0);
  delete command_a;
  delete command_b;
}

RedirectionCommand::RedirectionCommand(const char *cmd_line) : Command{cmd_line} {}
void RedirectionCommand::execute()
{
  prepare();
  std::string line;
  while (std::getline(std::cin, line)) //input from the file in.txt
  {
    fileOutput << line << std::endl; //output to the file out.txt
  }
  cleanup();
}
void RedirectionCommand::cleanup()
{
  fileOutput.close();
}
OverrideRedirectionCommand ::OverrideRedirectionCommand(const char *cmd_line) : RedirectionCommand{cmd_line} {}
void OverrideRedirectionCommand::prepare()
{
  fileOutput.open(parseCommandLine(cmd_line.c_str())[0], std::ofstream::out | std::ofstream::trunc);
}
AppendRedirectionCommand ::AppendRedirectionCommand(const char *cmd_line) : RedirectionCommand{cmd_line} {}
void AppendRedirectionCommand::prepare()
{
  fileOutput.open(parseCommandLine(cmd_line.c_str())[0], std::ofstream::out | std::ofstream::app);
}
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ timeout command~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
void TimeOutCommand::processAlarm(int signum)
{
  kill(inner_pid, 9);
}
TimeOutCommand::TimeOutCommand(const char *cmd_line) : Command{cmd_line}
{
}
void TimeOutCommand::execute()
{
  auto first_loc = this->cmd_line.find(args[1]);
  this->inner_command = this->cmd_line.substr(first_loc + args[1].size(), this->cmd_line.size() - args[1].size() - first_loc);
  inner_pid = fork();
  if (inner_pid == 0)
  {
    setpgrp();
    SmallShell::getInstance().executeCommand(inner_command.c_str());
    exit(0);
  }
  else
  {
    alarm(std::stoi(args[1]));
    SmallShell::getInstance().child_timed_out = inner_pid;
    SmallShell::getInstance().is_timed_out = true;
    SmallShell::getInstance().timedout_command = cmd_line;
    wait(NULL);
    SmallShell::getInstance().is_timed_out = false;
  }
}
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ jobs list ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //

JobsList::JobsList(){};
JobsList::~JobsList(){};

void JobsList::printJobsList()
{
  for (auto const &job : this->jobsMap)
  {
    if (job.second->isStopped)
    {
      std::cout << '[' << job.first << "] " << job.second->getCommandName()
                << " : " << job.second->pid << " " << to_string(this->getElapsedSeconds(*job.second)) << " (stopped)" << endl;
    }
    else
    {
      std::cout << '[' << job.first << "] " << job.second->getCommandName() << " : " << job.second->pid << " " << to_string(this->getElapsedSeconds(*job.second)) << endl;
    }
  }
}

void JobsList::addJob(int pid, Command *cmd, bool isStopped)
{
  int lastJobId;
  this->getLastJob(&lastJobId);
  int newJobId = lastJobId + 1;

  JobEntry *newJob = new JobEntry(pid, newJobId, cmd->cmd_line, time(NULL));

  // ctodo: use stopped

  this->jobsMap.insert(pair<int, JobsList::JobEntry *>(newJobId, newJob));
}

JobsList::JobEntry *JobsList::getLastJob(int *lastJobId)
{
  if (this->jobsMap.size() == 0)
  {
    *lastJobId = 0;
    return NULL;
  }
  *lastJobId = this->jobsMap.rbegin()->first;
  JobsList::JobEntry *res = this->jobsMap[*lastJobId];
  return res;
}

size_t JobsList::getJobCount()
{
  return this->jobsMap.size();
}

void JobsList::killAllJobs() {}

void JobsList::removeJobById(int jobId)
{
  delete this->jobsMap[jobId];
  this->jobsMap.erase(jobId);
}

void JobsList::removeFinishedJobs()
{
  for (auto const &jobPair : this->jobsMap)
  {
    if (is_pid_running(jobPair.second->pid) == false)
    {
      this->removeJobById(jobPair.second->id);
    }
  }
}

int JobsList::killJob(int jobId, int sig)
{
  if (this->jobsMap.find(jobId) == this->jobsMap.end())
  {
    string message = "smash error: kill: job-id " + to_string(jobId) + " does not exist\n";
    perror(message.c_str());
  }  
  return kill(this->jobsMap[jobId]->pid, sig);
}

double JobsList::getElapsedSeconds(JobEntry &job)
{
  time_t current_time;
  current_time = time(NULL);
  return difftime(current_time, job.insertTime);
}

JobsList::JobEntry *JobsList::getJobById(int jobId)
{
  return this->jobsMap[jobId];
}

string JobsList::JobEntry::getCommandName()
{
  return parseCommandLine(this->cmd_line.c_str())[0];
}

// bool JobsList::JobEntry::getIsStopped()
// {
//   bool is_suspended; 
//   int status;
//   cout<<getpid()<<" checks for "<<this->pid<<endl;
//   pid_t result = waitpid(this->pid, &status, WNOHANG);
//   cout<<"result is "<<result<<endl;
//   if(result == 0) {  
//     cout<<"status was "<<status;
//       if (WIFSTOPPED(status)) {
//           return true;
//       } else if (WIFCONTINUED(status)) {
//           return false;
//       }
//   }
//   return true;
// }
