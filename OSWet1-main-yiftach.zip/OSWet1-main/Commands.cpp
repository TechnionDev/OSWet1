#include <unistd.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <iomanip>
#include "Commands.h"
#include <map>

using namespace std;

const std::string WHITESPACE = " \n\r\t\f\v";

#if 0
#define FUNC_ENTRY() \
  cerr << __PRETTY_FUNCTION__ << " --> " << endl;

#define FUNC_EXIT() \
  cerr << __PRETTY_FUNCTION__ << " <-- " << endl;
#else
#define FUNC_ENTRY()
#define FUNC_EXIT()
#endif

#define PAGE_BUFFER_4K 4096

#define DEBUG_PRINT cerr << "DEBUG: "

#define EXEC(path, arg) \
  execvp((path), (arg));

vector<string> parseCommandLine(const char *cmd_line);

string _ltrim(const std::string &s)
{
  size_t start = s.find_first_not_of(WHITESPACE);
  return (start == std::string::npos) ? "" : s.substr(start);
}

string _rtrim(const std::string &s)
{
  size_t end = s.find_last_not_of(WHITESPACE);
  return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

string _trim(const std::string &s)
{
  return _rtrim(_ltrim(s));
}

int _parseCommandLine(const char *cmd_line, char **args)
{
  FUNC_ENTRY()
  int i = 0;
  std::istringstream iss(_trim(string(cmd_line)).c_str());
  for (std::string s; iss >> s;)
  {
    args[i] = (char *)malloc(s.length() + 1);
    memset(args[i], 0, s.length() + 1);
    strcpy(args[i], s.c_str());
    args[++i] = NULL;
  }
  return i;

  FUNC_EXIT()
}

bool _isBackgroundComamnd(const char *cmd_line)
{
  const string str(cmd_line);
  return str[str.find_last_not_of(WHITESPACE)] == '&';
}

void _removeBackgroundSign(char *cmd_line)
{
  const string str(cmd_line);
  // find last character other than spaces
  unsigned int idx = str.find_last_not_of(WHITESPACE);
  // if all characters are spaces then return
  // if (idx == string::npos) {
  // return;
  // }
  // if the command line does not end with & then return
  if (cmd_line[idx] != '&')
  {
    return;
  }
  // replace the & (background sign) with space and then remove all tailing spaces.
  cmd_line[idx] = ' ';
  // truncate the command line string up to the last non-space character
  cmd_line[str.find_last_not_of(WHITESPACE, idx) + 1] = 0;
}

// TODO: Add your implementation for classes in Commands.h

SmallShell::SmallShell() : prompt("smash")
{
  last_cd = new char[100];
  terminate = false;
  currentFgJobId = -1;
}

SmallShell::~SmallShell()
{
  delete[] last_cd;
}

/**
* Creates and returns a pointer to Command class which matches the given command line (cmd_line)
*/
Command *SmallShell::CreateCommand(const char *cmd_line)
{
  // return new GetCurrDirCommand(cmd_line);
  Command *wanted_command;
  string key;
  string command = _trim(string(cmd_line));

  std::map<std::string, Command *> builtInCommands = {
      {"pwd", new GetCurrDirCommand(cmd_line)},
      {"cd", new ChangeDirCommand(cmd_line)},
      {"ls", new ListDirectoryCommand(cmd_line)},
      {"chprompt", new ChangePromptCommand(cmd_line)},
      {"jobs", new JobsCommand(cmd_line, &this->jobslist)},
      {"fg", new ForegroundCommand(cmd_line, &this->jobslist)},
      {"bg", new BackgroundCommand(cmd_line, &this->jobslist)},
      {"kill", new KillCommand(cmd_line, &this->jobslist)},
      {"timeout", new TimeOutCommand(cmd_line)},
      {"cp", new CopyCommand(cmd_line)}};
  auto vec = parseCommandLine(command.c_str());

  if (command.find("|&") != std::string::npos || command.find("|") != std::string::npos || command.find(">>") != std::string::npos || command.find(">") != std::string::npos)
  {
    wanted_command = new PipeCommand(command.c_str());
    key = "pipe";
  }
  else
  {
    if (builtInCommands.find(vec[0]) != builtInCommands.end())
    {
      wanted_command = builtInCommands[vec[0]];
      key = vec[0];
    }
    else
    {
      wanted_command = new ExternalCommand(command.c_str());
      key = "external";
    }
  }
  for (auto iter : builtInCommands)
  {
    if (iter.first != key)
    {
      delete iter.second;
    }
  }
  return wanted_command;
}

void SmallShell::executeCommand(const char *cmd_line)
{
  this->jobslist.removeFinishedJobs();

  if (_isBackgroundComamnd(cmd_line))
  {
    char *new_cmd_line = strdup(cmd_line);
    _removeBackgroundSign(new_cmd_line);
    Command *c = CreateCommand(new_cmd_line);
    int pid = fork();
    if (pid == 0)
    {
      setpgrp();
      //close(1);
      //SmallShell::getInstance().terminate = true;
      c->execute();
      delete c;
      // return;
      exit(1);
    }
    this->jobslist.addJob(pid, c);
  }
  else
  {
    this->currentCommand = CreateCommand(cmd_line);
    this->currentCommand->execute();
    delete this->currentCommand;
    this->currentCommand = NULL;
  }
}
void SmallShell::changePrompt(const string prompt)
{
  this->prompt = prompt;
}
std::string SmallShell::getPrompt()
{
  return this->prompt;
}
bool SmallShell::is_last_command_set()
{
  return this->last_command_set;
}
void SmallShell::turn_last_command_flag_on()
{
  this->last_command_set = true;
  this->last_command_set = true;
}

// TODO: Add your implementation here
// for example:
// Command* cmd = CreateCommand(cmd_line);
// cmd->execute();
// Please note that you must fork smash process for some commands (e.g., external commands....)

#include "commands_impl.cpp"
/*----------------------Commands implementation----------------------*/
