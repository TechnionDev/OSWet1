#include <iostream>
#include <signal.h>
#include "signals.h"
#include "Commands.h"
#include <unistd.h>
#include <string.h>
#include <iostream>
#include <map>


using namespace std;

void ctrlZHandler(int sig_num) {  

  exit(1);

  if (SmallShell::getInstance().currentCommand == NULL){
    cout<<getpid()<<" exited on signalZ"<<endl;
    exit(1);
  }

  if (SmallShell::getInstance().currentFgJobId>0){
    cout<<getpid()<<" got FG"<<endl;
    SmallShell::getInstance().jobslist.killJob(SmallShell::getInstance().currentFgJobId,SIGSTOP);
    SmallShell::getInstance().jobslist.getJobById(SmallShell::getInstance().currentFgJobId)->isStopped=true;
  }
  else{
    int newJobPid = fork();    
    if (newJobPid==0){
      setpgrp();
      cout<<getpid()<<" started as child"<<endl;
      SmallShell::getInstance().terminate=true;
      SmallShell::getInstance().currentCommand=NULL;
      SmallShell::getInstance().currentFgJobId=-1;
      return;
    }
    cout<<getpid()<<" added "<<newJobPid<<" to jobs";
    SmallShell::getInstance().jobslist.addJob(newJobPid,SmallShell::getInstance().currentCommand,true);
  }  
}

void ctrlCHandler(int sig_num) {
  // exit(1);

  if (SmallShell::getInstance().currentCommand == NULL){
    cout<<getpid()<<" exited on signalZ"<<endl;
    exit(1);
  }

  if (SmallShell::getInstance().currentFgJobId>0){
    cout<<getpid()<<" got FG"<<endl;
    SmallShell::getInstance().jobslist.killJob(SmallShell::getInstance().currentFgJobId,SIGSTOP);
    SmallShell::getInstance().jobslist.getJobById(SmallShell::getInstance().currentFgJobId)->isStopped=true;
  }
  else{
    int newJobPid = fork();    
    if (newJobPid==0){
      setpgrp();
      cout<<getpid()<<" started as child"<<endl;
      SmallShell::getInstance().terminate=true;
      SmallShell::getInstance().currentCommand=NULL;
      SmallShell::getInstance().currentFgJobId=-1;
      return;
    }
    cout<<getpid()<<" added "<<newJobPid<<" to jobs";
    SmallShell::getInstance().jobslist.addJob(newJobPid,SmallShell::getInstance().currentCommand,true);
  }  
}

void alarmHandler(int sig_num) {
  if(SmallShell::getInstance().is_timed_out){
    std::cout << "smash: got an alarm"<<std::endl; // TODO: change this (why?)
    kill(SmallShell::getInstance().child_timed_out,9);
    std::cout << "smash: "<<SmallShell::getInstance().timedout_command<< " timed out"<<std::endl; // TODO: change this (why?)
    
  }
}

